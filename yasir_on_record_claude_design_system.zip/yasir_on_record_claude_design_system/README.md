# Yasir On Record — Claude Design System Folder

Upload this folder into Claude's "Link code from your computer" section.

## What Claude should read first

1. `src/index.html`
2. `src/design-system.css`
3. `design-tokens.json`

## Purpose

This folder contains the Yasir On Record brand identity and LinkedIn carousel design system for Yasir Dil.

The system is built for:
- LinkedIn carousels
- LinkedIn banners
- Thought leadership visuals
- Marketing strategy content
- Education marketing and CRM authority posts

## Visual rules

- Background: warm paper cream `#F2EBD8`
- Primary type: deep ink navy `#0E1623`
- Accent: terracotta `#D4633C`
- Highlight: soft clay `#F5C9B4`
- Headline font: Archivo Black
- Body font: Public Sans
- Editorial label font: Public Sans / JetBrains Mono
- Use one accent per slide
- Use one hand-drawn mark per slide maximum
- Keep the style bold, premium, minimal, and highly readable on mobile

## Standard carousel format

- 1080 × 1350 px per slide
- 4 to 6 slides
- Structure: Hook → Tension → Insight → Action → Profile CTA
- Header: `YASIR ON RECORD`
- Hashtag example: `#growthnotes`
- Issue format: `№ 01`

## Prompt to use after upload

Create a 6-slide LinkedIn carousel using this design system.

Topic: The 14-Day Lead Leak

Use the Yasir On Record editorial style:
warm paper background, ink typography, terracotta accent, soft-clay highlight pill, small metadata, issue number, and one hand-drawn terracotta mark per slide maximum.

Keep the design premium, bold, minimal, and readable on mobile.
